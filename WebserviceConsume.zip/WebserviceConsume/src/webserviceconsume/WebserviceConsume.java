/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webserviceconsume;

import java.util.Scanner;

/**
 *
 * @author TalhaMahmoodSheikh
 */
public class WebserviceConsume {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float a,b;
        Scanner in1 = new Scanner(System.in);
        System.out.println("Enter first number");
        a = in1.nextFloat();
        
        Scanner in2 = new Scanner(System.in);
        System.out.println("Enter second number");
        b = in2.nextFloat();
       /*  
        String Add= "add";
        String Subtract= "subtract";
        String Multiply = "multiply";
        String Divide= "divide";*/
        
       System.out.println("Choose the Option by its Number");
        System.out.println("1.Add"+"2.Subtract"+"3.Multiply"+"Divide");
        Scanner in3 = new Scanner(System.in);
        int choice = in3.nextInt();
        
        if ( choice == 1)
        {
            System.out.println(add(a,b));
        } else if( choice == 2){
            System.out.println(subtract(a,b));
        } else if (choice == 3){
            
            System.out.println(multiply(a,b));
        }
        else if (choice == 4){
            System.out.println(divide(a,b));
        } else {
        System.out.println("Wrong Choice");}
        
        /* System.out.println(add(a,b));
        System.out.println(subtract(a,b));
        System.out.println(multiply(a,b));
        System.out.println(divide(a,b));
        */
    }

    private static float add(float x, float y) {
        com.parasoft.wsdl.calculator.Calculator service = new com.parasoft.wsdl.calculator.Calculator();
        com.parasoft.wsdl.calculator.ICalculator port = service.getICalculator();
        return port.add(x, y);
    }

    private static float divide(float numerator, float denominator) {
        com.parasoft.wsdl.calculator.Calculator service = new com.parasoft.wsdl.calculator.Calculator();
        com.parasoft.wsdl.calculator.ICalculator port = service.getICalculator();
        return port.divide(numerator, denominator);
    }

    private static float multiply(float x, float y) {
        com.parasoft.wsdl.calculator.Calculator service = new com.parasoft.wsdl.calculator.Calculator();
        com.parasoft.wsdl.calculator.ICalculator port = service.getICalculator();
        return port.multiply(x, y);
    }

    private static float subtract(float x, float y) {
        com.parasoft.wsdl.calculator.Calculator service = new com.parasoft.wsdl.calculator.Calculator();
        com.parasoft.wsdl.calculator.ICalculator port = service.getICalculator();
        return port.subtract(x, y);
    }
    
}
