/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author TalhaMahmoodSheikh
 */
public class Menu extends JFrame implements ActionListener{
    private JFrame mainFrame;
   private JLabel headerLabel;
   private JLabel statusLabel;
   private JPanel controlPanel;
   

   public Menu(){
      prepareGUI();
   }
    public static void main(String[] args){
      Menu  swingControlDemo = new Menu();      
      swingControlDemo.showButtonDemo();
   }

   private void prepareGUI(){
      mainFrame = new JFrame("Java Swing Examples");
      mainFrame.setSize(400,400);
      mainFrame.setLayout(new GridLayout(3, 1));
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      });    
      headerLabel = new JLabel("", JLabel.CENTER);        
      statusLabel = new JLabel("",JLabel.CENTER);    

      statusLabel.setSize(350,100);

      controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());

      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
      //mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);
      mainFrame.setVisible(true);  
   }
    
  /* private static ImageIcon createImageIcon(String path, 
      String description) {
      java.net.URL imgURL = Menu.class.getResource(path);
      if (imgURL != null) {
         return new ImageIcon(imgURL, description);
      } else {            
         System.err.println("Couldn't find file: " + path);
         return null;
      }
   }   */

   private void showButtonDemo(){

      headerLabel.setText("Welcome to EMS"); 

      //resources folder should be inside SWING folder.
    //  ImageIcon icon = createImageIcon("/resources/java_icon.png","Java");

      JButton fcountryButton = new JButton("Find Country");        
      JButton fcurrencyButton = new JButton("Find Currency");
      JButton weatherButton = new JButton("Weather");
      JButton calculatorButton = new JButton("Calculator");  
      fcountryButton.setHorizontalTextPosition(SwingConstants.RIGHT);   

      fcountryButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Find country");
         }          
      });

      fcurrencyButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Find Currency");
         }
      });

      weatherButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Weather");
            //setVisible(true);
         }

          private void setVisible(boolean b) {
              throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
          }

          private void dispose() {
              throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
          }
      });
       calculatorButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Calculator");
           // dispose();
         }
       });

      controlPanel.add(fcountryButton);
      controlPanel.add(fcurrencyButton);
      controlPanel.add(weatherButton);  
      controlPanel.add(calculatorButton);

      mainFrame.setVisible(true);  
   }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
