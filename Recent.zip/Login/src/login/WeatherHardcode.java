/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author TalhaMahmoodSheikh
 */
public class WeatherHardcode {
    
   public static void main(String[] args) {
        // TODO code application logic here
        java.lang.String CityName= "Islamabad";
        java.lang.String CountryName= "Pakistan";
        System.out.println(getWeather(CityName,CountryName));
    
}

    private static String getWeather(java.lang.String cityName, java.lang.String countryName) {
        net.webservicex.GlobalWeather service = new net.webservicex.GlobalWeather();
        net.webservicex.GlobalWeatherSoap port = service.getGlobalWeatherSoap();
        return port.getWeather(cityName, countryName);
    }
   

    
    }

  

