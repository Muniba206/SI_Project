/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.util.Scanner;

/**
 *
 * @author TalhaMahmoodSheikh
 */
public class Weather {
    
    
    
     public static void main(String[] args) {
         String cityName,countryName;
         
         Scanner in1 = new Scanner(System.in);
         System.out.println("Enter city Name");
         cityName = in1.nextLine();
         
         Scanner in2 = new Scanner(System.in);
         System.out.println("Enter country Name");
         countryName = in2.nextLine();
         
         System.out.println(getWeather(cityName,countryName));
         
         
         
  }

    private static String getWeather(java.lang.String cityName, java.lang.String countryName) {
        net.webservicex.GlobalWeather service = new net.webservicex.GlobalWeather();
        net.webservicex.GlobalWeatherSoap port = service.getGlobalWeatherSoap();
        return port.getWeather(cityName, countryName);
    }

    void setVisible(boolean b) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
