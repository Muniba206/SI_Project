/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import javax.swing.AbstractButton;
 
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
/**
 *
 * @author TalhaMahmoodSheikh
 */
public class MenuEmp extends JFrame implements ActionListener{
    
  //  private Object btngroup;
    
   // private static final long serialVersionUID = 1L;
    private JRadioButton firstRadioButton;
    private JRadioButton secondRadioButton;
    private JRadioButton thirdRadioButton;
    private JRadioButton fourthRadioButton;
    private JRadioButton fifthRadioButton;
    private Object button;
    private Object btngroup;
    
    @SuppressWarnings("LeakingThisInConstructor")
    public MenuEmp(){

         super("Employee Menu");
        setSize(500,500);
        
        this.getContentPane().setLayout(new FlowLayout());


 firstRadioButton=new JRadioButton("Find Country",true);  
 secondRadioButton=new JRadioButton("Find Currency");
 thirdRadioButton=new JRadioButton("Check Weather");
 fourthRadioButton=new JRadioButton("Calculator");
 fifthRadioButton=new JRadioButton("Search");
 

 //Create a radio button group using ButtonGroup  
 ButtonGroup btngroup=new ButtonGroup();  

 btngroup.add(firstRadioButton);  
 btngroup.add(secondRadioButton);  
 btngroup.add(thirdRadioButton);
 btngroup.add(fourthRadioButton);
 btngroup.add(fifthRadioButton);
 setLayout(new FlowLayout());
 //Create a button with text ( What i select )  
 JButton button=new JButton("OK");  
 button.addActionListener(this);  
 //Add action listener to created button  
 
 add(firstRadioButton);
 add(secondRadioButton);
 add(thirdRadioButton);
 add(fourthRadioButton);
 add(fifthRadioButton);
 add(button);
 
  pack();
    }
 
 @Override
 //Get selected JRadioButton from ButtonGroup  
  public void actionPerformed(ActionEvent event)  
  {  
     if(event.getSource()==button) { 
     /*{  
        Enumeration<AbstractButton> allRadioButton=btngroup.getElements();  
        while(allRadioButton.hasMoreElements())  
        {  
           JRadioButton temp=(JRadioButton)allRadioButton.nextElement();  
           if(temp.isSelected())  
           {  
            JOptionPane.showMessageDialog(null,"You select : "+temp.getText());  
           }*/
         System.out.println( "Selected Radio Button: ");
        }
        
  }
  private static void createAndShowGUI() {

  //Create and set up the window.

  JFrame frame = new MenuEmp();

  //Display the window.
  frame.pack();
  frame.setVisible(true);
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
 public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
 
            @Override
            public void run() {
                createAndShowGUI();
            }
        });
    }
    }
     
